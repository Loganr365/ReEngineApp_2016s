/*#include <iostream>
#include <windows.h>
#include "Camera.h"
#include "RE\ReEngAppClass.h"
#include <SFML\Graphics.hpp>
using namespace std;

/*int main(void)
{
	Camera* oFoo = Camera::GetInstance();
	cout << oFoo->m_nVar << endl;


	Camera::ReleaseInstance();

	Camera* oBar = Camera::GetInstance();
	oBar->m_nVar = 50;
	cout << oFoo->m_nVar << endl;

	getchar();
}*/